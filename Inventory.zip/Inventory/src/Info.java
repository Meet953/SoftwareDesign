import java.io.Serializable;

public class Info implements Serializable {
	
	private String name;
	private String type;
	
	public Info(String n, String t){
		name=n;
		type=t;
	}
	
	public String readName(){return name;}
	public String readType(){return type;}

	public void resetName(String n){
		name = n;
	}
	
	public void resetType(String t){
		type = t;
	}
}
