
public class Global {

	public static String item;
}
