import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JList;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;


public class Inven {

	JFrame frame;
	private JTextField txtName;
	private JTextField txtType;
	private JTextField txtPrice;
	private JTextField txtItemName;


	LinkedList list = new LinkedList();
	DefaultListModel<String> listModel = new DefaultListModel<String>();
	private JTextField txtSearchItem;
	private JTextField txtSearchType;
	private JTextField txtUpdate;
	private JTextField trUpdateName;
	private JTextField trUpdateType;
	private JTextField trUpdatePrice;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inven window = new Inven();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Inven() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(253, 245, 230));
		frame.setBounds(100, 100, 687, 524);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(240, 248, 255));
		tabbedPane.setBounds(10, 0, 651, 474);
		frame.getContentPane().add(tabbedPane);
		
		JPanel Addpanel = new JPanel();
		Addpanel.setBackground(new Color(240, 255, 255));
		tabbedPane.addTab("ADD " + Global.item, null, Addpanel, null);
		tabbedPane.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		Addpanel.setLayout(null);
		
		JLabel label = new JLabel("INVENTORY");
		label.setFont(new Font("Sprocket BT", Font.BOLD, 18));
		label.setBounds(245, 48, 109, 23);
		Addpanel.add(label);
		
		
		JLabel label_1 = new JLabel("Item Name");
		label_1.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		label_1.setBounds(190, 132, 87, 23);
		Addpanel.add(label_1);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(310, 135, 109, 20);
		Addpanel.add(txtName);
		
		JLabel label_2 = new JLabel("Item Type");
		label_2.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		label_2.setBounds(190, 177, 87, 23);
		Addpanel.add(label_2);
		
		txtType = new JTextField();
		txtType.setColumns(10);
		txtType.setBounds(310, 180, 109, 20);
		Addpanel.add(txtType);
		
		JLabel label_3 = new JLabel("Item Price");
		label_3.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		label_3.setBounds(190, 224, 87, 23);
		Addpanel.add(label_3);
		
		txtPrice = new JTextField();
		txtPrice.setColumns(10);
		txtPrice.setBounds(310, 227, 109, 20);
		Addpanel.add(txtPrice);
		
		JLabel lblAddResult = new JLabel("");
		lblAddResult.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddResult.setForeground(Color.BLUE);
		lblAddResult.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblAddResult.setBounds(221, 343, 176, 23);
		Addpanel.add(lblAddResult);
		
		JButton btnAddfirst = new JButton("ADD FIRST");
		btnAddfirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String name=txtName.getText();
                 String type=txtType.getText();
                 String price=txtPrice.getText();
                 
                 if(name.length() > 0 && type.length() > 0 && price.length() > 0) {
                	 int indexOf=price.indexOf(".");
                	 String euro=price.substring(0,indexOf);
 	 		         String cents=price.substring(indexOf+1);
 	 		         int eu=Integer.parseInt(euro);
 	 		         int ce=Integer.parseInt(cents);   
 	 		         list.insert_first(name, type, eu, ce);
 	 		         
 	 		         lblAddResult.setForeground(Color.GREEN);
 	 		         lblAddResult.setText("SUCCESS");
 	 		         
 	 		         txtName.setText("");
 	                 txtType.setText("");
 	                 txtPrice.setText("");
                 }
			}
		});
		btnAddfirst.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnAddfirst.setBounds(174, 278, 109, 23);
		Addpanel.add(btnAddfirst);
		
		JButton btnAddlast = new JButton("ADD LAST");
		btnAddlast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String name=txtName.getText();
                 String type=txtType.getText();
                 String price=txtPrice.getText();
                 
                 if(name.length() > 0 && type.length() > 0 && price.length() > 0) {
                	 int indexOf=price.indexOf(".");
                	 String euro=price.substring(0,indexOf);
 	 		         String cents=price.substring(indexOf+1);
 	 		         int eu=Integer.parseInt(euro);
 	 		         int ce=Integer.parseInt(cents);   
 	 		         list.insert_last(name, type, eu, ce);
 	 		         
 	 		         lblAddResult.setForeground(Color.GREEN);
	 		         lblAddResult.setText("SUCCESS");
	 		         
	 		         txtName.setText("");
	                 txtType.setText("");
	                 txtPrice.setText("");
                 }
			}
		});
		btnAddlast.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnAddlast.setBounds(340, 278, 109, 23);
		Addpanel.add(btnAddlast);
		
		
		
		JPanel Deletepanel = new JPanel();
		Deletepanel.setBackground(new Color(240, 255, 255));
		tabbedPane.addTab("REMOVE " + Global.item, null, Deletepanel, null);
		Deletepanel.setLayout(null);
		
		JLabel lblDeleteResult = new JLabel("");
		lblDeleteResult.setHorizontalAlignment(SwingConstants.CENTER);
		lblDeleteResult.setForeground(Color.BLUE);
		lblDeleteResult.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblDeleteResult.setBounds(229, 332, 127, 23);
		Deletepanel.add(lblDeleteResult);
		
		
		JLabel label_4 = new JLabel("Item Name");
		label_4.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		label_4.setBounds(194, 152, 87, 23);
		Deletepanel.add(label_4);
		
		txtItemName = new JTextField();
		txtItemName.setColumns(10);
		txtItemName.setBounds(317, 155, 109, 20);
		Deletepanel.add(txtItemName);
		
		JLabel label_5 = new JLabel("INVENTORY");
		label_5.setFont(new Font("Sprocket BT", Font.BOLD, 18));
		label_5.setBounds(244, 52, 109, 23);
		Deletepanel.add(label_5);
		
		JButton btnDeletefirst = new JButton("REMOVE FIRST");
		btnDeletefirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = list.delete_first();
				if(name != null) {
					lblDeleteResult.setForeground(Color.GREEN);
					lblDeleteResult.setText(name + " DELETED"); 
				}
				else {
					lblDeleteResult.setForeground(Color.RED);
					lblDeleteResult.setText("FAILED"); 
				}
				
			}
		});
		
		btnDeletefirst.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnDeletefirst.setBounds(130, 276, 138, 23);
		Deletepanel.add(btnDeletefirst);
		
		JButton btnDeletespec = new JButton("REMOVE IT");
		btnDeletespec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String name=txtItemName.getText();
				 
				 if(name.length() > 0) {	 
					 if(list.delete_specific(name)) {
						 lblDeleteResult.setForeground(Color.GREEN);
						 lblDeleteResult.setText("SUCCESS");
					 }
					 else {
						 lblDeleteResult.setForeground(Color.RED);
						 lblDeleteResult.setText("FAILED");
					 }
				 }
				 else {
					 lblDeleteResult.setForeground(Color.RED);
					 lblDeleteResult.setText("FAILED");
				 }
			}
		});
		btnDeletespec.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnDeletespec.setBounds(229, 213, 128, 23);
		Deletepanel.add(btnDeletespec);
		
		JButton btnDeleteall = new JButton("EMPTY INVENTORY");
		btnDeleteall.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list.delete_all();
				lblDeleteResult.setForeground(Color.GREEN);
				lblDeleteResult.setText("SUCCESS");
			}
		});
		
		btnDeleteall.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnDeleteall.setBounds(327, 276, 162, 23);
		Deletepanel.add(btnDeleteall);
		
		
		JPanel Showpanel = new JPanel();
		Showpanel.setBackground(new Color(240, 255, 255));
		tabbedPane.addTab("SHOW " + Global.item, null, Showpanel, null);
		Showpanel.setLayout(null);
		
		
		JList<String> jlist = new JList<String>();
		//jlist.setBounds(76, 99, 395, 166);
		//Showpanel.add(jlist);
		
		JScrollPane jpane = new JScrollPane(jlist);
		jpane.setBounds(106, 99, 395, 166);
		Showpanel.add(jpane);
		
		
		JLabel lblCount = new JLabel("");
		lblCount.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblCount.setBounds(430, 74, 46, 14);
		Showpanel.add(lblCount);
		
		JButton btnShow = new JButton("SHOW");
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				list.printlist();	
				listModel.removeAllElements();
				
				ArrayList<String> arlist = list.display_all();
				for (int i = 0; i < arlist.size(); i++)
				{
				    listModel.addElement(arlist.get(i));
				}
				jlist.setModel(listModel);
				jlist.ensureIndexIsVisible(arlist.size());
				
				int c= list.count();
				lblCount.setText(c+" ");
				
			}
		});
		btnShow.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnShow.setBounds(260, 65, 107, 23);
		Showpanel.add(btnShow);
		
		JLabel label_8 = new JLabel("INVENTORY");
		label_8.setFont(new Font("Sprocket BT", Font.BOLD, 18));
		label_8.setBounds(260, 25, 109, 23);
		Showpanel.add(label_8);
		
		JLabel lblFile = new JLabel("");
		lblFile.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblFile.setBounds(236, 335, 133, 31);
		Showpanel.add(lblFile);
		
		JButton btnNewButton = new JButton("SAVE");
		btnNewButton.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				list.saveAll();
				lblFile.setText("SAVED TO FILE");
			}
		});
		btnNewButton.setBounds(110, 295, 89, 23);
		Showpanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("READ");
		btnNewButton_1.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list.readAll();
				lblFile.setText("READ FROM FILE");
			}
		});
		btnNewButton_1.setBounds(412, 295, 89, 23);
		Showpanel.add(btnNewButton_1);
		
		
		
		JPanel updatePanel = new JPanel();
		updatePanel.setBackground(new Color(240, 255, 255));
		tabbedPane.addTab("UPDATE " + Global.item, null, updatePanel, null);
		updatePanel.setLayout(null);
		
		JLabel label_9 = new JLabel("INVENTORY");
		label_9.setFont(new Font("Sprocket BT", Font.BOLD, 18));
		label_9.setBounds(259, 29, 109, 23);
		updatePanel.add(label_9);
		
		JLabel label_10 = new JLabel("Item Name");
		label_10.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		label_10.setBounds(176, 76, 87, 23);
		updatePanel.add(label_10);
		
		txtUpdate = new JTextField();
		txtUpdate.setColumns(10);
		txtUpdate.setBounds(363, 79, 109, 20);
		updatePanel.add(txtUpdate);
		
		
		JPanel uppanel = new JPanel();
		uppanel.setBounds(176, 176, 307, 163);
		updatePanel.add(uppanel);
		uppanel.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(33, 11, 87, 23);
		lblName.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		uppanel.add(lblName);
		
		trUpdateName = new JTextField();
		trUpdateName.setBounds(153, 14, 109, 20);
		trUpdateName.setColumns(10);
		uppanel.add(trUpdateName);
		
		JLabel lblItemPrice = new JLabel("Type");
		lblItemPrice.setBounds(33, 45, 87, 23);
		lblItemPrice.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		uppanel.add(lblItemPrice);
		
		trUpdateType = new JTextField();
		trUpdateType.setBounds(153, 52, 109, 20);
		trUpdateType.setColumns(10);
		uppanel.add(trUpdateType);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(89, 129, 109, 23);

		btnUpdate.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		uppanel.add(btnUpdate);
		
		JLabel lblPrice = new JLabel(" Price");
		lblPrice.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblPrice.setBounds(33, 83, 87, 23);
		uppanel.add(lblPrice);
		
		trUpdatePrice = new JTextField();
		trUpdatePrice.setColumns(10);
		trUpdatePrice.setBounds(153, 86, 109, 20);
		uppanel.add(trUpdatePrice);
		
		JLabel lblUpdateResult = new JLabel("");
		lblUpdateResult.setHorizontalAlignment(SwingConstants.CENTER);
		lblUpdateResult.setForeground(Color.BLUE);
		lblUpdateResult.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		lblUpdateResult.setBounds(238, 369, 176, 23);
		updatePanel.add(lblUpdateResult);
		
		uppanel.setVisible(false); 
		
		JButton btnFindUpdate = new JButton("FIND");
		btnFindUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String name = txtUpdate.getText();	
			if(name.length() > 0) {
				String results = list.search(name);
				if(results.equals("No Results Found")) {
					lblUpdateResult.setText(results);	
				}
				else {
					 uppanel.setVisible(true);
					 Item curr=list.returnItem(name);
	 	             trUpdateName.setText(curr.readName());
	 	             trUpdateType.setText(curr.readType());
	 	             trUpdatePrice.setText(curr.readPrice());
	 	           
	 	             txtUpdate.setEditable(false);
				}
			}
			else {
				lblUpdateResult.setForeground(Color.RED);
				lblUpdateResult.setText("FAILED");
			}
				
			}
		});
		
		
		btnFindUpdate.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
		btnFindUpdate.setBounds(259, 122, 109, 23);
		updatePanel.add(btnFindUpdate);
		
			
			JPanel Searchpanel = new JPanel();
			Searchpanel.setBackground(new Color(240, 255, 255));
			tabbedPane.addTab("SEARCH " + Global.item, null, Searchpanel, null);
			Searchpanel.setLayout(null);
			
			JLabel label_6 = new JLabel("Item Name");
			label_6.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			label_6.setBounds(109, 122, 87, 23);
			Searchpanel.add(label_6);
			
			txtSearchItem = new JTextField();
			txtSearchItem.setColumns(10);
			txtSearchItem.setBounds(267, 125, 109, 20);
			Searchpanel.add(txtSearchItem);
			
			JTextArea txtNameArea = new JTextArea();
			txtNameArea.setEditable(false);
			txtNameArea.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			txtNameArea.setBounds(203, 175, 236, 29);
			Searchpanel.add(txtNameArea);
			
			
			JButton btnSearch = new JButton("SEARCH");
			btnSearch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				
					String name = txtSearchItem.getText();
					
					if(name.length() > 0) {
						String result = list.search(name);
						txtNameArea.setVisible(true);
						txtNameArea.setText(result);
					}
				}
			});
			
			btnSearch.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			btnSearch.setBounds(453, 122, 109, 23);
			Searchpanel.add(btnSearch);
			
			JLabel label_7 = new JLabel("INVENTORY");
			label_7.setFont(new Font("Sprocket BT", Font.BOLD, 18));
			label_7.setBounds(267, 33, 109, 23);
			Searchpanel.add(label_7);
			
			JLabel lblItemType = new JLabel("Item Type");
			lblItemType.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			lblItemType.setBounds(109, 239, 87, 23);
			Searchpanel.add(lblItemType);
			
			txtSearchType = new JTextField();
			txtSearchType.setColumns(10);
			txtSearchType.setBounds(267, 242, 109, 20);
			Searchpanel.add(txtSearchType);
			
			JTextArea txtTypeArea = new JTextArea();
			txtTypeArea.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			txtTypeArea.setBounds(140, 259, 236, 63);
			//Searchpanel.add(txtTypeArea);
			
			JScrollPane scroll = new JScrollPane(txtTypeArea);
			scroll.setLocation(203, 300);
			Searchpanel.add(scroll);
			scroll.setSize( 240, 70 );
			
			JButton btnTypeSearch = new JButton("SEARCH");
			btnTypeSearch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					String type = txtSearchType.getText();
					if(type.length() > 0) {
						String results = list.search_type(type);
						if(results.length() > 0) {
							scroll.setVisible(true);
							txtTypeArea.setVisible(true);
							txtTypeArea.setText(results);
							txtTypeArea.setLineWrap(true);
							txtTypeArea.setWrapStyleWord(true);
						}
						else {
							scroll.setVisible(true);
							txtTypeArea.setVisible(true);
							txtTypeArea.setText("No Results Found");
						}
						
					}
				}
			});
			btnTypeSearch.setFont(new Font("Sprocket BT", Font.PLAIN, 15));
			btnTypeSearch.setBounds(453, 239, 109, 23);
			Searchpanel.add(btnTypeSearch);
			
			
			
			
			txtNameArea.setVisible(false);
			txtTypeArea.setVisible(false);
			scroll.setVisible(false);
	
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String search = txtUpdate.getText();
				 String name=trUpdateName.getText();
                 String type=trUpdateType.getText();
                 String price=trUpdatePrice.getText();
                               
                 if(name.length() > 0 && type.length() > 0 && price.length() > 0) {
                	 int indexOf=price.indexOf(".");
                	 String euro=price.substring(0,indexOf);
 	 		         String cents=price.substring(indexOf+1);
 	 		         int eu=Integer.parseInt(euro.toString());
 	 		         int ce=Integer.parseInt(cents.toString());   
 	 		         boolean res = list.updateItem(search, name, type, eu, ce);
 	 		         if(res) {
 	 		        	lblUpdateResult.setForeground(Color.GREEN);
 	 	 		        lblUpdateResult.setText("SUCCESS"); 
 	 	 		        txtUpdate.setText("");
 	 	 		        txtUpdate.setEditable(true);
 	 	 		        trUpdateName.setText("");
 	 	 		        trUpdateType.setText("");
 	 	 		        trUpdatePrice.setText("");
 	 		         }
 	 		         else {
 	 		        	lblUpdateResult.setForeground(Color.RED);
 	 	 		        lblUpdateResult.setText("FAILED"); 
 	 		         }
 	 		         
 	 		         
 	 		        
                 } 
				
			}
		});
		
		
	}
}
