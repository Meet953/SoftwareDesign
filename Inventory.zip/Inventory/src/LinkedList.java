import java.awt.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

class LinkedList{
        private Item head;
        
	    public  LinkedList(){head=null;}
	    
	    
	    
		public  void insert_first(String n, String t, int e,int c)
	    {      Item temp =new Item(n,t,e,c);
			   temp.next=head;
			   head=temp;
	    }
		
		public  void insert_last(String n, String t, int e,int c)
        {   
			if(head == null) {
				 Item temp =new Item(n,t,e,c);
				 temp.next=head;
				 head=temp;
			}
			else {
				Item tempnew =new Item(n,t,e,c);
				Item temp=head;
				
				 while(temp.next!=null) {
		               temp=temp.next;
		          }
				 
				temp.next=tempnew;
				tempnew.next = null;
			}
			
        }
       
		public  Item readItem(int el)
        {     
			if (head==null|| this.count()<el)
        	   return null;
			   
			Item temp=head;
            int current=1;
            while(current!=el) {
                current++;
                temp=temp.next;
            }
            return temp; 
         } 


		public int count()
	    {      
			Item temp=head;
            int res=0;
	        while(temp!=null) {
               res++;
	           temp=temp.next;
	        }
	        return res; 
	    }


		public String delete_first()
	    {         
			if (head==null)return null;
		    String res=head.readName();
		    head = head.next;
		    return res;
        }
		
		public boolean delete_specific(String n)
		{
				
			if(head.readName().equals(n)) {
				 head = head.next;
				 return true;
			}
			
			Item previous;
			Item current;
			
			previous = null; current = head;
	         while (current != null)
	         {
	            if(current.readName().equals(n))
	            {
	            	current = current.next;
	            	if (previous == null) previous = current;
	            	else previous.next = current;
	            	// count--;
	            	return true;
	            	} else {
	            		previous = current;
	            		current = current.next;
	            	}
	         } //end while
	         return false;
		}
		
		
		public  String search(String s1)
        {    
			String retstr = "No Results Found";
			Item temp=head;
			while(temp!=null) {
              if(temp.readName().equals(s1))
              {
            	 retstr = temp.details();
              }
               temp=temp.next;
			}
			return retstr;              
        }
		
		public Item returnItem(String s1)
        {      
			if (head==null)
				return null;
			 
			Item temp=head;
			while(temp!=null) 
			{
	              if(temp.readName().equals(s1))
	              {
	            	 return temp;
	              }
	               temp=temp.next;
			}
			return null;
        } 
		
		public boolean updateItem(String search, String name, String type, int e, int c)
        {      
			if (head==null)
				return false;
			 
			Item temp=head;
			while(temp!=null) 
			{
	              if(temp.readName().equals(search))
	              {
	            	  temp.resetName(name);
	            	  temp.resetType(type);
	            	  temp.resetItemPrice(e, c);
	            	  return true;
	              }
	               temp=temp.next;
			}
			return false;
        } 
		
		
		public  String search_type(String s1)
        {    
			String retstr = "" ;
			Item temp=head;
			while(temp!=null) {
              if(temp.readType().equals(s1))
              {
            	 retstr += temp.details() + "\n";
              }
               temp=temp.next;
			}
			return retstr;              
        }
		
		public void delete_all()
	    {         
			head=null;
        }


		public ArrayList<String> display_all()
	     {
			  ArrayList<String> arlist = new ArrayList<>();

		      Item temp=head;
		      
			  while(temp!=null) {
			      arlist.add(temp.details());
			      temp=temp.next;
			  }
			   
			  return arlist;                 
		}
		
	     public void printlist()
	     {
		      Item temp=head;
		      System.out.println("\nList:");
		      System.out.print("HEAD->");
			  while(temp!=null) {
			      temp.print();
			      temp=temp.next;
			  }
			               
			  System.out.print("NULL");                  
		}
	     
	     
	     public void saveAll() {
	    	 
	    	 File file = new File("file.txt");
	         try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
	         
	    	 
	    	 try {
	             FileOutputStream fileOut =new FileOutputStream("file.txt");
	             ObjectOutputStream out = new ObjectOutputStream(fileOut);
	            
	             Item temp=head;
			     
				 while(temp!=null) {
					 out.writeObject(temp);
					 temp=temp.next;
				 }
	             out.close();
	             fileOut.close();
	            
	          } catch (IOException i) {
	             i.printStackTrace();
	          }
	    	
	     }
	     
	     public void readAll() {
	    	 
	    	 try {
	    		 FileInputStream fileIn =new FileInputStream("file.txt"); 
	    		 ObjectInputStream inputStream = new ObjectInputStream(fileIn);
	    		 
	    		 Object temp = null;
	    		 while(true) {
	    			
	    			 temp =  inputStream.readObject();
	    			 if (temp instanceof Item) {
	    				 
	    				 if(head == null) {
	    					 ((Item) temp).next=head;
	    					 head=((Item) temp);
	    					   
	    				 }else {
	    					 Item start=head;
			  				 while(start.next!=null) {
			  		               start=start.next;
			  		          }
			  				 
			  				 start.next=(Item) temp;
			  				 ((Item) temp).next = null;
	    				 }
	    				
		    		 }
	    		}
	    		
	    		}catch (IOException i) {
	             
	        } catch (ClassNotFoundException e) {
	        }
	    	    
	     }
	     
   }


   